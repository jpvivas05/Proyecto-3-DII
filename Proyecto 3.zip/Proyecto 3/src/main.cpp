//**************/
// Universidad del Valle de Guatemala
// BE3029 - Electronica Digital 2
// Allan Lemus | Juan Vivas
// 17/11/2025
// Proyecto 3 Digital II
// MCU: ESP32 dev kit 1.0
//**************/
//**************/
// Librerias
//**************/
#include <Arduino.h>
#include <Adafruit_NeoPixel.h>
#include <stdint.h>
#include "Wire.h"
//**************/
// Definiciones
//**************/
// Pines Neopixel
#define led 12
#define pin 13
// Cantidad de neopixels
#define NUMPIXELS 3
// Dirección de sensor esclavo
#define I2C_DEV_ADDR 0x48
//Definición de pines UART
#define RX 16
#define TX 17

uint8_t i = 0;

// Led neopixel
Adafruit_NeoPixel pixels(NUMPIXELS, pin, NEO_GRB + NEO_KHZ800);
#define DELAYVAL 500
//**************/
// Prototipos de funciones
//**************/
//**************/
// Variables globales
//**************/
//**************/
// ISRs Rutinas de Interrupcion
//**************/
//**************/
// Configuracion
//**************/
void setup() {
  Serial.begin(115200);
  //Inicialización de UART con STM
  Serial2.begin(115200, SERIAL_8N1, RX, TX);
  Serial.setDebugOutput(true);
  //Inicialización de Neopixels e I2C
  pinMode(led,OUTPUT);
  Wire.begin();
  pixels.begin();
  //Lectura inicial en sensor
  for (uint8_t i = 0; i<10; i++){
    Wire.requestFrom(I2C_DEV_ADDR, 2);
  }
}
//**************/
// Loop Principal
//**************/
void loop() {
  //Solo se activa si se recibe algo por el UART
    while (Serial2.available() > 0) {
      //Guarda lo recibido en el comando
      char cmd = Serial2.read();
      if (cmd == '1') {
        //Solicita una medición
        uint8_t bytesReceived = Wire.requestFrom(I2C_DEV_ADDR, 2);
        if (bytesReceived == 2) {
          uint8_t temp[2];
          Wire.readBytes(temp, 2);
          //Conversión de binario en 2 bytes a decimal
          int8_t msb = temp[0];
          uint8_t lsb = temp[1];
          int16_t raw = ((int16_t)msb << 1) | (lsb >> 7);
          float temperature = raw * 0.5f;
          //Indicador externo de medición
          Serial.println("Tomando temperatura...");
          pixels.clear();
          pixels.setPixelColor(0, pixels.Color(60, 60, 0));
          pixels.show();
          delay(1000);
          Serial.printf("Temperatura: %.2f °C\n", temperature);
          char TXbuffer[8];
          int len = sprintf(TXbuffer, "%.2f", temperature);
          //Envía dato convertido por UART
          Serial2.write((uint8_t*)TXbuffer, len);
          //Indicador de envío
          pixels.clear();
          pixels.setPixelColor(0, pixels.Color(0, 0, 60));
          pixels.show();
          delay(1000);
        } else {
          Serial.printf("Error: se recibieron %u bytes\n", bytesReceived);
        }
      }if (cmd  == '2'){
        //Indicador de toma de registro SD en STM
        pixels.clear();
        pixels.setPixelColor(0, pixels.Color(60, 60, 60));
        pixels.show();
      }else{
        Serial.print("Se recibió otro comando: ");
        Serial.println(cmd);
        //Reinicio (generalmente se envía un comando 0)
        pixels.clear();
        pixels.setPixelColor(0, pixels.Color(0, 60, 0));
        pixels.show();
      }
  }
  }
//**************/
// Otras funciones
//**************/